// http://phrogz.net/JS/classes/OOPinJS.html

/*
* Constructor
* 	note: frequency
* 	context: audiocontext
*/
function Voice (note,context,attack,decay,sustain,release){
	//Attributes
	var _os; //oscillator
	var _envelope; //gain node

	//Set all of our public variables
	var _note = note;
	var _context = context;
	var _attack = attack; //milliseconds
	var _decay = decay; //milliseconds
	var _sustain = sustain; //percent volume
	var _release = release; //milliseconds

		//Create the envelope for the note
	// 1. Begin at silent 
	// 2. Ramp up in /attack/ time to max volume
	// 3. Slope down to sustain volume in /decay/ time
	// 4. Stay there until stopped
	this.setEnvelope = function() {
		var now = _context.currentTime;
		var decayStart = now + (_attack / 1000.0);

		_envelope.gain.setValueAtTime(0.0,now);
		_envelope.gain.linearRampToValueAtTime(1.0,decayStart);
		_envelope.gain.setTargetValueAtTime((_sustain / 100.0),decayStart,(_decay / 1000.0) + 0.001);
	}

	//Stop the note
	// 1. Stop any future actions that the oscillator should have
	// 2. Begin at full volume
	// 3. Ramp down to silent in /release/ time
	// 4. Stop the oscillator after /release/ time
	this.stop = function() {
		var now = _context.currentTime;
		var end = now + (_release / 1000.0);

		_envelope.gain.cancelScheduledValues(now);
		_envelope.gain.setValueAtTime(_envelope.gain.value,now);
		_envelope.gain.setTargetValueAtTime(0.0,now, (_release / 1000.0));

		_osc.stop(release);
	}

	/*******CONSTRUCTOR*************/

	//Connect the components
	_osc = _context.createOscillator();
	_envelope = _context.createGain();
	_osc.connect(_envelope);
	_envelope.connect(_context.destination);

	//Set the frequency of the oscillator
	_osc.frequency.setValueAtTime(_note,0);

	this.setEnvelope();
	_osc.start();
}
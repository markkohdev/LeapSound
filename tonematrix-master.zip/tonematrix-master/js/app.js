if (!window.webkitAudioContext)
{
	alert('No WebAudio support');
}
else
{
	window.onload = new tm.Core();
}
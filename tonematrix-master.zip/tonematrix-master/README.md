# ToneMatrix
==========
http://carlbarrdahl.se/tm/


### Changelog
##### May 6 2013
* Base36 encoding for melodies (thanks /u/dllu)
* Melodies can now be sent as links
* Pause sound when window looses focus
* Able to paint notes with click and move